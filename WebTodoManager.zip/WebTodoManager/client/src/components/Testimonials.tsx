import { useState, useEffect } from 'react';
import { TitleSection } from '@/components/ui/title-section';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

type Testimonial = {
  id: number;
  text: string;
  author: {
    name: string;
    role: string;
    image: string;
  };
  rating: number;
};

const testimonials: Testimonial[] = [
  {
    id: 1,
    text: "Excelente serviço, usei durante toda a viagem em Floripa! As bikes são novas e o atendimento é super atencioso. Recomendo para todos que querem conhecer a cidade de um jeito diferente.",
    author: {
      name: "Ana M.",
      role: "Turista, Florianópolis",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100"
    },
    rating: 5
  },
  {
    id: 2,
    text: "A bike elétrica foi perfeita para os morros de BH! Consegui explorar a cidade sem me cansar e ainda fiz um passeio incrível. O app de navegação ajudou bastante também.",
    author: {
      name: "João P.",
      role: "Morador, Belo Horizonte",
      image: "https://images.unsplash.com/photo-1600486913747-55e5470d6f40?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100"
    },
    rating: 5
  },
  {
    id: 3,
    text: "Utilizamos as bikes infantis para passear com as crianças no parque e foi uma experiência incrível. As bikes são seguras e as crianças amaram. O único ponto é que poderia ter mais opções de tamanho.",
    author: {
      name: "Carla S.",
      role: "Mãe, São Paulo",
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100"
    },
    rating: 4
  }
];

export default function Testimonials() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => {
      window.removeEventListener('resize', checkMobile);
    };
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % testimonials.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  return (
    <section id="depoimentos" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <TitleSection 
          title="O Que Nossos Clientes Dizem" 
          subtitle="Experiências reais de quem já pedala com a gente."
        />
        
        <div className="relative">
          <div className="overflow-hidden">
            <div 
              className="flex transition-transform duration-300 ease-in-out"
              style={{ 
                transform: `translateX(-${currentSlide * 100}%)`,
                width: `${testimonials.length * 100}%`
              }}
            >
              {testimonials.map((testimonial) => (
                <div 
                  key={testimonial.id} 
                  className="w-full md:w-1/2 lg:w-1/3 px-4 flex-shrink-0"
                  style={{ width: isMobile ? '100%' : 'calc(100% / 3)' }}
                >
                  <div className="bg-light rounded-xl shadow-sm p-6 h-full">
                    <div className="flex items-center mb-4">
                      <div className="text-secondary flex">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className="h-5 w-5" 
                            fill={i < testimonial.rating ? "currentColor" : "none"} 
                          />
                        ))}
                      </div>
                    </div>
                    <p className="italic mb-4">{testimonial.text}</p>
                    <div className="flex items-center">
                      <img 
                        src={testimonial.author.image} 
                        alt={testimonial.author.name} 
                        className="w-12 h-12 rounded-full object-cover mr-4"
                      />
                      <div>
                        <h4 className="font-heading font-semibold">{testimonial.author.name}</h4>
                        <p className="text-sm text-gray-600">{testimonial.author.role}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <button 
            onClick={prevSlide}
            className="absolute left-0 top-1/2 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-md text-primary hover:text-secondary transition-colors focus:outline-none hidden md:block"
            aria-label="Previous slide"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button 
            onClick={nextSlide}
            className="absolute right-0 top-1/2 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-md text-primary hover:text-secondary transition-colors focus:outline-none hidden md:block"
            aria-label="Next slide"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
        
        <div className="flex justify-center mt-6 md:hidden">
          {testimonials.map((_, index) => (
            <button 
              key={index}
              onClick={() => goToSlide(index)}
              className={`mx-1 p-1 rounded-full ${currentSlide === index ? 'bg-primary' : 'bg-gray-300'}`}
              aria-label={`Go to slide ${index + 1}`}
            ></button>
          ))}
        </div>
      </div>
    </section>
  );
}
