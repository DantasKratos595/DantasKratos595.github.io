interface TitleSectionProps {
  title: string;
  subtitle?: string;
  center?: boolean;
}

export function TitleSection({ title, subtitle, center = true }: TitleSectionProps) {
  return (
    <div className={`mb-12 ${center ? 'text-center' : ''}`}>
      <h2 className="text-3xl font-heading font-bold mb-4 text-primary inline-block relative">
        {title}
        <span className={`absolute bottom-0 ${center ? 'left-1/2 transform -translate-x-1/2' : 'left-0'} w-20 h-1 bg-secondary`}></span>
      </h2>
      {subtitle && <p className="text-lg max-w-2xl mx-auto mt-6">{subtitle}</p>}
    </div>
  );
}
