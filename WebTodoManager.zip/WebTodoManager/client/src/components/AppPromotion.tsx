export default function AppPromotion() {
  return (
    <section className="bg-primary py-16 text-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-2/3 mb-8 md:mb-0">
            <h2 className="text-3xl font-heading font-bold mb-4">Baixe nosso aplicativo</h2>
            <p className="text-lg max-w-2xl mb-6">
              Tenha acesso a todos os recursos na palma da sua mão. Alugue bikes, veja locais disponíveis, desbloqueie e mais!
            </p>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
              <a 
                href="#" 
                className="flex items-center px-4 py-2 bg-black rounded-md hover:bg-gray-900 transition-colors"
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-6 w-6 mr-3" 
                  viewBox="0 0 24 24" 
                  fill="currentColor"
                >
                  <path d="M17.566 10.199c-.143-3.526 2.877-5.23 3.009-5.308-1.641-2.395-4.194-2.723-5.098-2.754-2.15-.221-4.22 1.279-5.312 1.279-1.107 0-2.789-1.25-4.592-1.215-2.342.036-4.53 1.371-5.73 3.471-2.467 4.27-.627 10.559 1.74 14.013 1.176 1.684 2.564 3.572 4.372 3.506 1.766-.07 2.422-1.123 4.551-1.123 2.104 0 2.717 1.123 4.54 1.082 1.881-.029 3.062-1.686 4.196-3.383 1.342-1.916 1.883-3.803 1.91-3.9-.043-.014-3.629-1.383-3.67-5.5M14.54 3.104c.961-1.176 1.611-2.783 1.424-4.391-1.379.057-3.076.936-4.071 2.094-.879 1.02-1.654 2.684-1.453 4.252 1.535.115 3.116-.773 4.1-1.955" />
                </svg>
                <div>
                  <div className="text-xs">Baixe na</div>
                  <div className="text-sm font-medium">App Store</div>
                </div>
              </a>
              <a 
                href="#" 
                className="flex items-center px-4 py-2 bg-black rounded-md hover:bg-gray-900 transition-colors"
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-6 w-6 mr-3" 
                  viewBox="0 0 24 24" 
                  fill="currentColor"
                >
                  <path d="M3.609 1.814 13.792 12 3.61 22.186C2.804 21.654 2.1685 20.939 1.7359 20.1019 1.3033 19.2647 1.0877 18.3386 1.106 17.4 1.106 15.421 1.969 13.61 3.609 12.401v-.8007c-1.64-1.209-2.503-3.02-2.503-5 0-2.792 1.425-5.253 3.609-6.786zm6.747-1.475 10 10c.293.293.293.767 0 1.061l-10 10c-.293.293-.767.293-1.061 0-.293-.293-.293-.767 0-1.061l9.47-9.47L9.296 1.4s-.293-.293 0-.586c.293-.293.767-.768 1.06-.475z" />
                </svg>
                <div>
                  <div className="text-xs">Disponível no</div>
                  <div className="text-sm font-medium">Google Play</div>
                </div>
              </a>
            </div>
          </div>
          <div className="md:w-1/3 flex justify-center">
            <img 
              src="https://images.unsplash.com/photo-1616348436168-de43ad0db179?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&h=1000" 
              alt="App Pedal Livre" 
              className="max-w-[200px] h-auto rounded-3xl shadow-2xl transform -rotate-6"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
