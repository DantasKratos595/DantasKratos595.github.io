import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const navLinks = [
  { href: "#sobre", label: "Sobre Nós" },
  { href: "#modelos", label: "Modelos" },
  { href: "#planos", label: "Planos" },
  { href: "#locais", label: "Locais" },
  { href: "#depoimentos", label: "Depoimentos" },
  { href: "#blog", label: "Blog" },
  { href: "#contato", label: "Contato" },
];

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      if (offset > 100) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  return (
    <header className={`fixed w-full bg-white bg-opacity-95 z-50 transition-all duration-300 ${scrolled ? 'shadow-md' : ''}`}>
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <a href="#" className="flex items-center">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-8 w-8 mr-2 text-primary" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="9" />
              <circle cx="12" cy="12" r="3" />
              <line x1="12" y1="3" x2="12" y2="9" />
              <line x1="12" y1="15" x2="12" y2="21" />
              <line x1="3" y1="12" x2="9" y2="12" />
              <line x1="15" y1="12" x2="21" y2="12" />
            </svg>
            <h1 className="text-2xl font-heading font-bold text-primary">Pedal Livre</h1>
          </a>
        </div>
        
        <nav className="hidden md:flex space-x-6">
          {navLinks.map((link) => (
            <a 
              key={link.href} 
              href={link.href} 
              className="font-heading font-medium hover:text-primary transition-colors"
            >
              {link.label}
            </a>
          ))}
        </nav>
        
        <button 
          onClick={toggleMobileMenu}
          className="md:hidden text-primary focus:outline-none"
        >
          {mobileMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
        
        <a 
          href="#" 
          className="hidden md:block bg-primary hover:bg-opacity-90 text-white font-heading font-medium px-4 py-2 rounded-md transition-all"
        >
          Entrar
        </a>
      </div>
      
      {mobileMenuOpen && (
        <div className="md:hidden bg-white w-full border-t border-gray-200">
          <div className="container mx-auto px-4 py-2 flex flex-col space-y-3">
            {navLinks.map((link) => (
              <a 
                key={link.href} 
                href={link.href} 
                className="font-heading font-medium py-2 border-b border-gray-100"
                onClick={closeMobileMenu}
              >
                {link.label}
              </a>
            ))}
            <a 
              href="#" 
              className="bg-primary text-white font-heading font-medium px-4 py-2 rounded-md text-center"
              onClick={closeMobileMenu}
            >
              Entrar
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
