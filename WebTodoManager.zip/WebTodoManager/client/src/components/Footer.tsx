import { Link } from 'wouter';

type NavLink = {
  href: string;
  label: string;
};

type FooterColumn = {
  title: string;
  links: NavLink[];
};

const navLinks: NavLink[] = [
  { href: "#sobre", label: "Sobre Nós" },
  { href: "#modelos", label: "Modelos" },
  { href: "#planos", label: "Planos e Preços" },
  { href: "#locais", label: "Locais" },
  { href: "#depoimentos", label: "Depoimentos" },
  { href: "#blog", label: "Blog" },
  { href: "#contato", label: "Contato" },
];

const cityLinks: NavLink[] = [
  { href: "#", label: "São Paulo" },
  { href: "#", label: "Rio de Janeiro" },
  { href: "#", label: "Florianópolis" },
  { href: "#", label: "Belo Horizonte" },
  { href: "#", label: "Curitiba" },
  { href: "#", label: "Salvador" },
];

const legalLinks: NavLink[] = [
  { href: "#", label: "Termos de Uso" },
  { href: "#", label: "Política de Privacidade" },
  { href: "#", label: "Política de Cookies" },
  { href: "#", label: "Termos de Aluguel" },
  { href: "#", label: "Seguro" },
];

const footerColumns: FooterColumn[] = [
  { title: "Navegação", links: navLinks },
  { title: "Cidades", links: cityLinks },
  { title: "Legal", links: legalLinks },
];

export default function Footer() {
  return (
    <footer className="bg-dark text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-8 w-8 text-secondary mr-2" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <circle cx="12" cy="12" r="9" />
                <circle cx="12" cy="12" r="3" />
                <line x1="12" y1="3" x2="12" y2="9" />
                <line x1="12" y1="15" x2="12" y2="21" />
                <line x1="3" y1="12" x2="9" y2="12" />
                <line x1="15" y1="12" x2="21" y2="12" />
              </svg>
              <h2 className="text-2xl font-heading font-bold">Pedal Livre</h2>
            </div>
            <p className="mb-4">Transformando a mobilidade urbana com bicicletas acessíveis e sustentáveis.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-secondary transition-colors" aria-label="Instagram">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                </svg>
              </a>
              <a href="#" className="text-white hover:text-secondary transition-colors" aria-label="Facebook">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                </svg>
              </a>
              <a href="#" className="text-white hover:text-secondary transition-colors" aria-label="TikTok">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M9 12a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z"></path>
                  <path d="M20 9V4a1 1 0 0 0-1-1h-5"></path>
                  <path d="M15 12v-2a4 4 0 0 0-4-4c-1.18 0-2.27.4-3.14 1.07"></path>
                  <path d="M19 7.5v5c0 7-6 5-7 2"></path>
                </svg>
              </a>
              <a href="#" className="text-white hover:text-secondary transition-colors" aria-label="YouTube">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"></path>
                  <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"></polygon>
                </svg>
              </a>
            </div>
          </div>
          
          {footerColumns.map((column, index) => (
            <div key={index}>
              <h3 className="text-lg font-heading font-bold mb-4 border-b border-gray-700 pb-2">
                {column.title}
              </h3>
              <ul className="space-y-2">
                {column.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a 
                      href={link.href} 
                      className="hover:text-secondary transition-colors"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        
        <div className="border-t border-gray-700 mt-10 pt-6 flex flex-col md:flex-row justify-between">
          <p>&copy; 2023 Pedal Livre. Todos os direitos reservados.</p>
          <div className="mt-4 md:mt-0">
            <a href="#" className="hover:text-secondary transition-colors">Termos de Uso</a>
            <span className="mx-2">|</span>
            <a href="#" className="hover:text-secondary transition-colors">Política de Privacidade</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
