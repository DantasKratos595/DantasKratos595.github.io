import { TitleSection } from '@/components/ui/title-section';

type BikeModel = {
  id: number;
  name: string;
  description: string;
  image: string;
  features: string[];
};

const bikeModels: BikeModel[] = [
  {
    id: 1,
    name: "Bike Urbana",
    description: "Leve e prática para o dia a dia na cidade",
    image: "https://images.unsplash.com/photo-1529422643029-d4585747aaf2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    features: ["8 marchas", "Cesto frontal", "Aro 26\""]
  },
  {
    id: 2,
    name: "Bike Elétrica",
    description: "Com assistência para subidas e longas distâncias",
    image: "https://images.unsplash.com/photo-1571068316344-75bc76f77890?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    features: ["Bateria 350W", "45km autonomia", "Aro 29\""]
  },
  {
    id: 3,
    name: "Bike Infantil",
    description: "Para os pequenos aventureiros",
    image: "https://images.unsplash.com/photo-1575909812264-6902b55846ad?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    features: ["Rodinhas opcionais", "Diversos tamanhos", "Coloridas"]
  },
  {
    id: 4,
    name: "Bike Dupla",
    description: "Perfeita para passeios a dois",
    image: "https://images.unsplash.com/photo-1583467875263-d50dec37a88c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    features: ["Tandem", "21 marchas", "Aro 26\""]
  }
];

export default function BikeModels() {
  return (
    <section id="modelos" className="py-20 bg-light">
      <div className="container mx-auto px-4">
        <TitleSection 
          title="Modelos de Bicicleta" 
          subtitle="Escolha o modelo ideal para sua aventura. Temos opções para todos os gostos, idades e necessidades."
        />
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {bikeModels.map((bike) => (
            <div 
              key={bike.id}
              className="bg-white rounded-xl shadow-md overflow-hidden transition-transform transform hover:-translate-y-2 hover:shadow-lg"
            >
              <img 
                src={bike.image} 
                alt={bike.name} 
                className="w-full h-48 object-cover"
              />
              <div className="p-5">
                <h3 className="text-xl font-heading font-bold mb-2">{bike.name}</h3>
                <p className="text-gray-600 mb-4">{bike.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {bike.features.map((feature, index) => (
                    <span key={index} className="bg-gray-100 text-xs px-2 py-1 rounded-full">
                      {feature}
                    </span>
                  ))}
                </div>
                <button className="w-full py-2 bg-primary hover:bg-opacity-90 text-white font-heading font-medium rounded-md transition-colors">
                  Ver Detalhes
                </button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-10">
          <a 
            href="#" 
            className="inline-flex items-center px-6 py-3 bg-white border border-primary text-primary font-heading font-semibold rounded-md hover:bg-primary hover:text-white transition-colors"
          >
            Ver todos os modelos
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-4 w-4 ml-2" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <line x1="5" y1="12" x2="19" y2="12"></line>
              <polyline points="12 5 19 12 12 19"></polyline>
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
}
