import { TitleSection } from '@/components/ui/title-section';
import { CalendarIcon, Clock } from 'lucide-react';

type BlogPost = {
  id: number;
  title: string;
  excerpt: string;
  image: string;
  date: string;
  readTime: string;
};

const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "Dicas para andar de bike na cidade com segurança",
    excerpt: "Aprenda a navegar pelo trânsito urbano, conheça as regras de segurança e saiba como se preparar para pedalar no dia a dia da cidade.",
    image: "https://images.unsplash.com/photo-1571333250630-f0230c320b6d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
    date: "15 mai 2023",
    readTime: "5 min de leitura"
  },
  {
    id: 2,
    title: "Os melhores roteiros para ciclistas urbanos",
    excerpt: "Descubra os circuitos mais interessantes para explorar a cidade de bike, incluindo parques, mirantes e pontos turísticos acessíveis.",
    image: "https://images.unsplash.com/photo-1503376780353-7e6692767b70?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
    date: "3 mai 2023",
    readTime: "8 min de leitura"
  },
  {
    id: 3,
    title: "Como a bicicleta ajuda o meio ambiente",
    excerpt: "Entenda o impacto positivo do uso da bicicleta para a redução da emissão de carbono e para a construção de cidades mais sustentáveis.",
    image: "https://images.unsplash.com/photo-1592150621744-aca64f48394a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
    date: "28 abr 2023",
    readTime: "6 min de leitura"
  }
];

export default function Blog() {
  return (
    <section id="blog" className="py-20 bg-light">
      <div className="container mx-auto px-4">
        <TitleSection 
          title="Nosso Blog" 
          subtitle="Dicas, roteiros e novidades sobre ciclismo urbano."
        />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {blogPosts.map((post) => (
            <article 
              key={post.id}
              className="bg-white rounded-xl shadow-md overflow-hidden transition-transform transform hover:-translate-y-2 hover:shadow-lg"
            >
              <img 
                src={post.image} 
                alt={post.title} 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-2">
                  <CalendarIcon className="h-4 w-4 mr-2" />
                  <span>{post.date}</span>
                  <span className="mx-2">•</span>
                  <Clock className="h-4 w-4 mr-2" />
                  <span>{post.readTime}</span>
                </div>
                <h3 className="text-xl font-heading font-bold mb-2">{post.title}</h3>
                <p className="text-gray-600 mb-4">{post.excerpt}</p>
                <a 
                  href="#" 
                  className="inline-flex items-center text-primary hover:text-secondary transition-colors font-medium"
                >
                  Ler mais
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-4 w-4 ml-2" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                  >
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                  </svg>
                </a>
              </div>
            </article>
          ))}
        </div>
        
        <div className="text-center mt-10">
          <a 
            href="#" 
            className="inline-flex items-center px-6 py-3 bg-white border border-primary text-primary font-heading font-semibold rounded-md hover:bg-primary hover:text-white transition-colors"
          >
            Ver mais artigos
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-4 w-4 ml-2" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <line x1="5" y1="12" x2="19" y2="12"></line>
              <polyline points="12 5 19 12 12 19"></polyline>
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
}
