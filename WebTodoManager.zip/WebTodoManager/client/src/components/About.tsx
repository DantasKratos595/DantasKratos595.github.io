import { TitleSection } from '@/components/ui/title-section';
import { Leaf, Wallet, Heart, MapPin } from 'lucide-react';

export default function About() {
  return (
    <section id="sobre" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1519583272095-6433daf26b6e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Pessoas pedalando em cidade" 
              className="rounded-xl shadow-lg"
            />
          </div>
          <div className="md:w-1/2">
            <TitleSection title="Sobre Nós" center={false} />
            <p className="mb-4 text-lg">
              Fundada em 2021, a <span className="font-semibold">Pedal Livre</span> nasceu da paixão pela mobilidade urbana e pela sustentabilidade.
            </p>
            <p className="mb-6 text-lg">
              Oferecemos bicicletas para aluguel de forma prática, ecológica e acessível em várias cidades brasileiras. Nosso compromisso é transformar a maneira como as pessoas se locomovem, contribuindo para um futuro mais verde.
            </p>
            
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="flex items-start">
                <Leaf className="text-secondary h-6 w-6 mr-3 mt-1" />
                <div>
                  <h3 className="font-heading font-semibold">Ecológico</h3>
                  <p className="text-sm">Zero emissões, 100% sustentável</p>
                </div>
              </div>
              <div className="flex items-start">
                <Wallet className="text-secondary h-6 w-6 mr-3 mt-1" />
                <div>
                  <h3 className="font-heading font-semibold">Econômico</h3>
                  <p className="text-sm">Preços acessíveis para todos</p>
                </div>
              </div>
              <div className="flex items-start">
                <Heart className="text-secondary h-6 w-6 mr-3 mt-1" />
                <div>
                  <h3 className="font-heading font-semibold">Saudável</h3>
                  <p className="text-sm">Exercício enquanto se desloca</p>
                </div>
              </div>
              <div className="flex items-start">
                <MapPin className="text-secondary h-6 w-6 mr-3 mt-1" />
                <div>
                  <h3 className="font-heading font-semibold">Conveniente</h3>
                  <p className="text-sm">Pontos de retirada estratégicos</p>
                </div>
              </div>
            </div>
            
            <a 
              href="#modelos" 
              className="inline-flex items-center font-heading font-semibold text-primary hover:text-secondary transition-colors"
            >
              Conheça nossos modelos
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-4 w-4 ml-2" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <line x1="5" y1="12" x2="19" y2="12"></line>
                <polyline points="12 5 19 12 12 19"></polyline>
              </svg>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
