import { useState } from 'react';
import { TitleSection } from '@/components/ui/title-section';
import { MapPin } from 'lucide-react';

type Location = {
  id: number;
  name: string;
  address: string;
  hours: string;
  bikesAvailable: number;
};

const locations: Location[] = [
  {
    id: 1,
    name: "Centro",
    address: "Pça. da República, 123",
    hours: "8h às 20h",
    bikesAvailable: 12
  },
  {
    id: 2,
    name: "Parque Ibirapuera",
    address: "Portão 3, s/n",
    hours: "7h às 22h",
    bikesAvailable: 3
  },
  {
    id: 3,
    name: "Estação Paulista",
    address: "Av. Paulista, 900",
    hours: "6h às 23h",
    bikesAvailable: 0
  }
];

const cities = ["São Paulo", "Rio de Janeiro", "Florianópolis", "Belo Horizonte"];

export default function Locations() {
  const [selectedCity, setSelectedCity] = useState<string>("");

  return (
    <section id="locais" className="py-20 bg-light">
      <div className="container mx-auto px-4">
        <TitleSection 
          title="Locais de Retirada" 
          subtitle="Estamos em pontos estratégicos pela cidade para facilitar seu acesso."
        />
        
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <div className="flex flex-col sm:flex-row justify-between items-center">
              <h3 className="text-xl font-heading font-bold mb-4 sm:mb-0">Encontre o ponto mais próximo</h3>
              <div className="flex flex-col sm:flex-row gap-3">
                <select 
                  className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                >
                  <option value="">Selecione a cidade</option>
                  {cities.map((city, index) => (
                    <option key={index} value={city}>{city}</option>
                  ))}
                </select>
                <button className="px-4 py-2 bg-primary text-white font-heading font-medium rounded-md hover:bg-opacity-90 transition-colors">
                  Buscar
                </button>
              </div>
            </div>
          </div>
          
          {/* Map placeholder */}
          <div className="h-96 bg-gray-100 relative overflow-hidden">
            <div 
              className="absolute inset-0 bg-cover bg-center opacity-70" 
              style={{ backgroundImage: "url('https://images.unsplash.com/photo-1486848538113-ce1a4923fbc5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')" }}
            ></div>
            <div className="absolute inset-0 flex items-center justify-center flex-col text-center p-6">
              <MapPin className="h-16 w-16 text-secondary mb-4" />
              <h3 className="text-2xl font-heading font-bold mb-2">Mapa Interativo</h3>
              <p className="max-w-lg">
                Selecione uma cidade para visualizar os pontos de retirada disponíveis. 
                Cada ponto mostra informações como horário de funcionamento e disponibilidade de bicicletas.
              </p>
            </div>
          </div>
          
          <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            {locations.map((location) => (
              <div key={location.id} className="p-4 border border-gray-200 rounded-lg">
                <div className="flex items-start">
                  <MapPin className="text-secondary h-5 w-5 mr-3 mt-1" />
                  <div>
                    <h4 className="font-heading font-semibold">{location.name}</h4>
                    <p className="text-sm text-gray-600">{location.address}</p>
                    <p className="text-sm text-gray-600">{location.hours}</p>
                    <div className="mt-2">
                      <span 
                        className={`inline-block px-2 py-1 text-xs rounded-full ${
                          location.bikesAvailable > 5 
                            ? 'bg-green-100 text-green-800' 
                            : location.bikesAvailable > 0 
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {location.bikesAvailable} bikes disponíveis
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
