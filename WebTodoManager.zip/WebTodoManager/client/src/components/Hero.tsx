import { ChevronDown } from 'lucide-react';

export default function Hero() {
  return (
    <section 
      className="relative pt-24 md:pt-0 h-screen min-h-[600px] bg-cover bg-center flex items-center justify-center" 
      style={{ 
        backgroundImage: "linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://images.unsplash.com/photo-1517649763962-0c623066013b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')" 
      }}
    >
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-6xl font-heading font-bold text-white mb-6 animate-fadeIn">
          Pedal Livre
        </h1>
        <p className="text-xl md:text-2xl font-heading font-semibold text-white mb-8">
          Viva a cidade no seu ritmo!
        </p>
        <div className="space-y-3 md:space-y-0 md:space-x-4 mb-10 flex flex-col md:flex-row justify-center items-center">
          <a 
            href="#planos" 
            className="w-full md:w-auto px-8 py-3 bg-secondary hover:bg-opacity-90 text-white font-heading font-semibold rounded-md shadow-lg transition-all transform hover:-translate-y-1"
          >
            Alugue Agora
          </a>
          <a 
            href="#planos" 
            className="w-full md:w-auto px-8 py-3 bg-accent hover:bg-opacity-90 text-white font-heading font-semibold rounded-md shadow-lg transition-all transform hover:-translate-y-1"
          >
            Ver Planos
          </a>
        </div>
        <div className="flex justify-center space-x-6 text-white mt-8">
          <div className="text-center">
            <div className="text-4xl font-bold">10+</div>
            <div className="text-sm mt-1">Cidades</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold">5000+</div>
            <div className="text-sm mt-1">Usuários</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold">100+</div>
            <div className="text-sm mt-1">Locais</div>
          </div>
        </div>
      </div>
      <div className="absolute bottom-5 left-0 right-0 text-center">
        <a href="#sobre" className="text-white animate-bounce inline-block">
          <ChevronDown className="h-6 w-6" />
        </a>
      </div>
    </section>
  );
}
