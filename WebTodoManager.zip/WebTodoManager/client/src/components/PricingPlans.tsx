import { TitleSection } from '@/components/ui/title-section';
import { Check, X } from 'lucide-react';

type PricingPlan = {
  id: number;
  name: string;
  price: number;
  unit: string;
  description: string;
  features: {
    text: string;
    included: boolean;
  }[];
  isPopular?: boolean;
};

const pricingPlans: PricingPlan[] = [
  {
    id: 1,
    name: "Horário",
    price: 10,
    unit: "hora",
    description: "Ideal para passeios curtos e turistas.",
    features: [
      { text: "Até 4 horas", included: true },
      { text: "Capacete incluso", included: true },
      { text: "Mapa de rotas", included: true },
      { text: "Seguro premium", included: false }
    ]
  },
  {
    id: 2,
    name: "Diário",
    price: 40,
    unit: "dia",
    description: "Perfeito para explorar a cidade.",
    features: [
      { text: "24 horas", included: true },
      { text: "Capacete + Cadeado", included: true },
      { text: "App de navegação", included: true },
      { text: "Seguro básico", included: true }
    ],
    isPopular: true
  },
  {
    id: 3,
    name: "Semanal",
    price: 120,
    unit: "semana",
    description: "Ótimo para férias na cidade.",
    features: [
      { text: "7 dias", included: true },
      { text: "Kit completo", included: true },
      { text: "Manutenção inclusa", included: true },
      { text: "Seguro completo", included: true }
    ]
  },
  {
    id: 4,
    name: "Mensal",
    price: 250,
    unit: "mês",
    description: "Para quem usa regularmente.",
    features: [
      { text: "30 dias", included: true },
      { text: "Kit premium", included: true },
      { text: "Suporte prioritário", included: true },
      { text: "Seguro premium", included: true }
    ]
  }
];

export default function PricingPlans() {
  return (
    <section id="planos" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <TitleSection 
          title="Planos e Preços" 
          subtitle="Escolha o plano que melhor se adapta às suas necessidades. Flexibilidade é nossa palavra-chave."
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {pricingPlans.map((plan) => (
            <div 
              key={plan.id}
              className="bg-white rounded-xl border border-gray-200 overflow-hidden transition-transform transform hover:-translate-y-2 hover:shadow-lg"
            >
              <div className="p-6">
                <h3 className="text-xl font-heading font-bold mb-2">{plan.name}</h3>
                <div className="text-3xl font-bold text-primary mb-4">
                  R${plan.price}<span className="text-sm text-gray-500 font-normal">/{plan.unit}</span>
                </div>
                <p className="text-gray-600 mb-6">{plan.description}</p>
                <ul className="space-y-2 mb-6">
                  {plan.features.map((feature, index) => (
                    <li key={index} className={`flex items-center ${!feature.included ? 'opacity-50' : ''}`}>
                      {feature.included ? (
                        <Check className="text-secondary h-4 w-4 mr-2" />
                      ) : (
                        <X className="text-gray-400 h-4 w-4 mr-2" />
                      )}
                      <span>{feature.text}</span>
                    </li>
                  ))}
                </ul>
                <button 
                  className={`w-full py-2 ${plan.isPopular ? 'bg-secondary' : 'bg-primary'} hover:bg-opacity-90 text-white font-heading font-medium rounded-md transition-colors`}
                >
                  Selecionar
                </button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="bg-light rounded-xl p-6 mt-12 text-center">
          <h3 className="text-xl font-heading font-bold mb-4">Pacotes Especiais</h3>
          <p className="mb-4">Oferecemos pacotes turísticos com guia, descontos para grupos e planos corporativos.</p>
          <a 
            href="#contato" 
            className="inline-flex items-center text-primary hover:text-secondary transition-colors font-medium"
          >
            Entre em contato para mais informações
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-4 w-4 ml-2" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <line x1="5" y1="12" x2="19" y2="12"></line>
              <polyline points="12 5 19 12 12 19"></polyline>
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
}
