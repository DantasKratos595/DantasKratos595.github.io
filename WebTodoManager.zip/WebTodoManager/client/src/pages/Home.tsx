import { useEffect } from 'react';
import Hero from '@/components/Hero';
import Navbar from '@/components/Navbar';
import About from '@/components/About';
import BikeModels from '@/components/BikeModels';
import PricingPlans from '@/components/PricingPlans';
import Locations from '@/components/Locations';
import Testimonials from '@/components/Testimonials';
import Blog from '@/components/Blog';
import Contact from '@/components/Contact';
import AppPromotion from '@/components/AppPromotion';
import Footer from '@/components/Footer';

export default function Home() {
  useEffect(() => {
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        
        if (targetElement) {
          window.scrollTo({
            top: (targetElement as HTMLElement).offsetTop - 80,
            behavior: 'smooth'
          });
        }
      });
    });

    // Sticky header on scroll
    const header = document.querySelector('header');
    let lastScrollTop = 0;
    
    const handleScroll = () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      
      if (scrollTop > 100) {
        header?.classList.add('shadow-md');
      } else {
        header?.classList.remove('shadow-md');
      }
      
      lastScrollTop = scrollTop;
    };

    window.addEventListener('scroll', handleScroll);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div className="min-h-screen w-full">
      <Navbar />
      <Hero />
      <About />
      <BikeModels />
      <PricingPlans />
      <Locations />
      <Testimonials />
      <Blog />
      <Contact />
      <AppPromotion />
      <Footer />
    </div>
  );
}
