import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import React from "react";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
}

export function generateRating(rating: number): JSX.Element[] {
  const stars: JSX.Element[] = [];
  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 >= 0.5;
  
  for (let i = 0; i < fullStars; i++) {
    stars.push(
      React.createElement("span", { key: `star-${i}`, className: "text-yellow-400" }, "★")
    );
  }
  
  if (halfStar) {
    stars.push(
      React.createElement("span", { key: "half-star", className: "text-yellow-400" }, "★")
    );
  }
  
  const emptyStars = 5 - stars.length;
  for (let i = 0; i < emptyStars; i++) {
    stars.push(
      React.createElement("span", { key: `empty-${i}`, className: "text-gray-300" }, "★")
    );
  }
  
  return stars;
}

export function getSmoothScrollOffset(): number {
  // Adjust the offset based on header height
  return 80; // matches the header height + some padding
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}
