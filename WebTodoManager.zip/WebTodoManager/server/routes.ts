import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  app.get("/api/bikes", async (req, res) => {
    try {
      const bikes = await storage.getAllBikes();
      res.json(bikes);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve bikes" });
    }
  });

  app.get("/api/bikes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid bike ID" });
      }
      
      const bike = await storage.getBike(id);
      if (!bike) {
        return res.status(404).json({ message: "Bike not found" });
      }
      
      res.json(bike);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve bike" });
    }
  });

  app.get("/api/locations", async (req, res) => {
    try {
      const locations = await storage.getAllLocations();
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve locations" });
    }
  });

  app.get("/api/testimonials", async (req, res) => {
    try {
      const testimonials = await storage.getAllTestimonials();
      res.json(testimonials);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve testimonials" });
    }
  });

  app.get("/api/blog-posts", async (req, res) => {
    try {
      const blogPosts = await storage.getAllBlogPosts();
      res.json(blogPosts);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve blog posts" });
    }
  });

  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactMessageSchema.parse(req.body);
      const contactMessage = await storage.createContactMessage(validatedData);
      res.status(201).json({ message: "Message sent successfully", id: contactMessage.id });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid form data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  app.post("/api/rentals", async (req, res) => {
    try {
      // This would normally validate a user session
      // For demo purposes, we'll just check if the request contains the required data
      const { bikeId, startDate, endDate, totalPrice } = req.body;
      
      if (!bikeId || !startDate || !endDate || !totalPrice) {
        return res.status(400).json({ message: "Missing required rental data" });
      }
      
      // Mock user ID for demo
      const userId = 1;
      
      const rental = await storage.createRental({
        userId,
        bikeId,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        totalPrice,
        status: "pending"
      });
      
      res.status(201).json({ message: "Rental created successfully", rental });
    } catch (error) {
      res.status(500).json({ message: "Failed to create rental" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
