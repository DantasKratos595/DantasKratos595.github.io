import { users, type User, type InsertUser } from "@shared/schema";
import { type Bike, type InsertBike } from "@shared/schema";
import { type Location, type InsertLocation } from "@shared/schema";
import { type Rental, type InsertRental } from "@shared/schema";
import { type ContactMessage, type InsertContactMessage } from "@shared/schema";
import { type BlogPost, type InsertBlogPost } from "@shared/schema";
import { type Testimonial, type InsertTestimonial } from "@shared/schema";

// Interface with all required CRUD operations
export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Bikes
  getBike(id: number): Promise<Bike | undefined>;
  getAllBikes(): Promise<Bike[]>;
  createBike(bike: InsertBike): Promise<Bike>;
  updateBike(id: number, bike: Partial<InsertBike>): Promise<Bike | undefined>;
  
  // Locations
  getLocation(id: number): Promise<Location | undefined>;
  getAllLocations(): Promise<Location[]>;
  createLocation(location: InsertLocation): Promise<Location>;
  
  // Rentals
  getRental(id: number): Promise<Rental | undefined>;
  getUserRentals(userId: number): Promise<Rental[]>;
  createRental(rental: InsertRental): Promise<Rental>;
  updateRentalStatus(id: number, status: string): Promise<Rental | undefined>;
  
  // Contact Messages
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getAllContactMessages(): Promise<ContactMessage[]>;
  markContactMessageAsRead(id: number): Promise<ContactMessage | undefined>;
  
  // Blog Posts
  getBlogPost(id: number): Promise<BlogPost | undefined>;
  getAllBlogPosts(): Promise<BlogPost[]>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  
  // Testimonials
  getTestimonial(id: number): Promise<Testimonial | undefined>;
  getAllTestimonials(): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
  approveTestimonial(id: number): Promise<Testimonial | undefined>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private bikes: Map<number, Bike>;
  private locations: Map<number, Location>;
  private rentals: Map<number, Rental>;
  private contactMessages: Map<number, ContactMessage>;
  private blogPosts: Map<number, BlogPost>;
  private testimonials: Map<number, Testimonial>;
  
  private userIdCounter: number;
  private bikeIdCounter: number;
  private locationIdCounter: number;
  private rentalIdCounter: number;
  private contactMessageIdCounter: number;
  private blogPostIdCounter: number;
  private testimonialIdCounter: number;

  constructor() {
    this.users = new Map();
    this.bikes = new Map();
    this.locations = new Map();
    this.rentals = new Map();
    this.contactMessages = new Map();
    this.blogPosts = new Map();
    this.testimonials = new Map();
    
    this.userIdCounter = 1;
    this.bikeIdCounter = 1;
    this.locationIdCounter = 1;
    this.rentalIdCounter = 1;
    this.contactMessageIdCounter = 1;
    this.blogPostIdCounter = 1;
    this.testimonialIdCounter = 1;
    
    // Initialize with some data
    this.seedData();
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }
  
  // Bikes
  async getBike(id: number): Promise<Bike | undefined> {
    return this.bikes.get(id);
  }
  
  async getAllBikes(): Promise<Bike[]> {
    return Array.from(this.bikes.values());
  }
  
  async createBike(insertBike: InsertBike): Promise<Bike> {
    const id = this.bikeIdCounter++;
    const bike: Bike = { ...insertBike, id };
    this.bikes.set(id, bike);
    return bike;
  }
  
  async updateBike(id: number, bikeData: Partial<InsertBike>): Promise<Bike | undefined> {
    const bike = this.bikes.get(id);
    if (!bike) return undefined;
    
    const updatedBike = { ...bike, ...bikeData };
    this.bikes.set(id, updatedBike);
    return updatedBike;
  }
  
  // Locations
  async getLocation(id: number): Promise<Location | undefined> {
    return this.locations.get(id);
  }
  
  async getAllLocations(): Promise<Location[]> {
    return Array.from(this.locations.values());
  }
  
  async createLocation(insertLocation: InsertLocation): Promise<Location> {
    const id = this.locationIdCounter++;
    const location: Location = { ...insertLocation, id };
    this.locations.set(id, location);
    return location;
  }
  
  // Rentals
  async getRental(id: number): Promise<Rental | undefined> {
    return this.rentals.get(id);
  }
  
  async getUserRentals(userId: number): Promise<Rental[]> {
    return Array.from(this.rentals.values()).filter(
      (rental) => rental.userId === userId
    );
  }
  
  async createRental(insertRental: InsertRental): Promise<Rental> {
    const id = this.rentalIdCounter++;
    const rental: Rental = { ...insertRental, id, createdAt: new Date() };
    this.rentals.set(id, rental);
    return rental;
  }
  
  async updateRentalStatus(id: number, status: string): Promise<Rental | undefined> {
    const rental = this.rentals.get(id);
    if (!rental) return undefined;
    
    const updatedRental = { ...rental, status };
    this.rentals.set(id, updatedRental);
    return updatedRental;
  }
  
  // Contact Messages
  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = this.contactMessageIdCounter++;
    const message: ContactMessage = { 
      ...insertMessage, 
      id, 
      createdAt: new Date(),
      isRead: false 
    };
    this.contactMessages.set(id, message);
    return message;
  }
  
  async getAllContactMessages(): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values());
  }
  
  async markContactMessageAsRead(id: number): Promise<ContactMessage | undefined> {
    const message = this.contactMessages.get(id);
    if (!message) return undefined;
    
    const updatedMessage = { ...message, isRead: true };
    this.contactMessages.set(id, updatedMessage);
    return updatedMessage;
  }
  
  // Blog Posts
  async getBlogPost(id: number): Promise<BlogPost | undefined> {
    return this.blogPosts.get(id);
  }
  
  async getAllBlogPosts(): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values());
  }
  
  async createBlogPost(insertPost: InsertBlogPost): Promise<BlogPost> {
    const id = this.blogPostIdCounter++;
    const post: BlogPost = { ...insertPost, id };
    this.blogPosts.set(id, post);
    return post;
  }
  
  // Testimonials
  async getTestimonial(id: number): Promise<Testimonial | undefined> {
    return this.testimonials.get(id);
  }
  
  async getAllTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values()).filter(
      (testimonial) => testimonial.isApproved
    );
  }
  
  async createTestimonial(insertTestimonial: InsertTestimonial): Promise<Testimonial> {
    const id = this.testimonialIdCounter++;
    const testimonial: Testimonial = { 
      ...insertTestimonial, 
      id, 
      isApproved: false,
      createdAt: new Date() 
    };
    this.testimonials.set(id, testimonial);
    return testimonial;
  }
  
  async approveTestimonial(id: number): Promise<Testimonial | undefined> {
    const testimonial = this.testimonials.get(id);
    if (!testimonial) return undefined;
    
    const updatedTestimonial = { ...testimonial, isApproved: true };
    this.testimonials.set(id, updatedTestimonial);
    return updatedTestimonial;
  }
  
  // Seed some initial data
  private seedData() {
    // Add sample user
    this.createUser({
      username: "johndoe",
      password: "password123",
      email: "john@example.com",
      name: "John Doe",
      phone: "11999999999"
    });
    
    // Add sample locations
    const locations = [
      {
        name: "Centro",
        address: "Pça. da República, 123",
        city: "São Paulo",
        hours: "8h às 20h",
        latitude: "-23.543",
        longitude: "-46.642"
      },
      {
        name: "Parque Ibirapuera",
        address: "Portão 3, s/n",
        city: "São Paulo",
        hours: "7h às 22h",
        latitude: "-23.587",
        longitude: "-46.657"
      },
      {
        name: "Estação Paulista",
        address: "Av. Paulista, 900",
        city: "São Paulo",
        hours: "6h às 23h",
        latitude: "-23.565",
        longitude: "-46.652"
      }
    ];
    
    locations.forEach(location => this.createLocation(location));
    
    // Add sample bikes
    const bikes = [
      {
        model: "Bike Urbana",
        type: "urban",
        description: "Leve e prática para o dia a dia na cidade",
        hourlyRate: 1000, // in cents
        dailyRate: 4000, // in cents
        weeklyRate: 12000, // in cents
        monthlyRate: 25000, // in cents
        imageUrl: "https://images.unsplash.com/photo-1529422643029-d4585747aaf2",
        isAvailable: true,
        features: ["8 marchas", "Cesto frontal", "Aro 26"],
        locationId: 1
      },
      {
        model: "Bike Elétrica",
        type: "electric",
        description: "Com assistência para subidas e longas distâncias",
        hourlyRate: 2000, // in cents
        dailyRate: 6000, // in cents
        weeklyRate: 18000, // in cents
        monthlyRate: 35000, // in cents
        imageUrl: "https://images.unsplash.com/photo-1571068316344-75bc76f77890",
        isAvailable: true,
        features: ["Bateria 350W", "45km autonomia", "Aro 29"],
        locationId: 2
      },
      {
        model: "Bike Infantil",
        type: "kids",
        description: "Para os pequenos aventureiros",
        hourlyRate: 800, // in cents
        dailyRate: 3000, // in cents
        weeklyRate: 10000, // in cents
        monthlyRate: 20000, // in cents
        imageUrl: "https://images.unsplash.com/photo-1575909812264-6902b55846ad",
        isAvailable: true,
        features: ["Rodinhas opcionais", "Diversos tamanhos", "Coloridas"],
        locationId: 1
      },
      {
        model: "Bike Dupla",
        type: "tandem",
        description: "Perfeita para passeios a dois",
        hourlyRate: 2500, // in cents
        dailyRate: 7000, // in cents
        weeklyRate: 20000, // in cents
        monthlyRate: 40000, // in cents
        imageUrl: "https://images.unsplash.com/photo-1583467875263-d50dec37a88c",
        isAvailable: true,
        features: ["Tandem", "21 marchas", "Aro 26"],
        locationId: 3
      }
    ];
    
    bikes.forEach(bike => this.createBike(bike));
    
    // Add sample testimonials
    const testimonials = [
      {
        userId: null,
        name: "Ana M.",
        role: "Turista, Florianópolis",
        text: "Excelente serviço, usei durante toda a viagem em Floripa! As bikes são novas e o atendimento é super atencioso. Recomendo para todos que querem conhecer a cidade de um jeito diferente.",
        rating: 5,
        imageUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2",
        isApproved: true,
        createdAt: new Date()
      },
      {
        userId: null,
        name: "João P.",
        role: "Morador, Belo Horizonte",
        text: "A bike elétrica foi perfeita para os morros de BH! Consegui explorar a cidade sem me cansar e ainda fiz um passeio incrível. O app de navegação ajudou bastante também.",
        rating: 5,
        imageUrl: "https://images.unsplash.com/photo-1600486913747-55e5470d6f40",
        isApproved: true,
        createdAt: new Date()
      },
      {
        userId: null,
        name: "Carla S.",
        role: "Mãe, São Paulo",
        text: "Utilizamos as bikes infantis para passear com as crianças no parque e foi uma experiência incrível. As bikes são seguras e as crianças amaram. O único ponto é que poderia ter mais opções de tamanho.",
        rating: 4,
        imageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956",
        isApproved: true,
        createdAt: new Date()
      }
    ];
    
    testimonials.forEach(t => {
      const id = this.testimonialIdCounter++;
      this.testimonials.set(id, { ...t, id });
    });
    
    // Add sample blog posts
    const blogPosts = [
      {
        title: "Dicas para andar de bike na cidade com segurança",
        excerpt: "Aprenda a navegar pelo trânsito urbano, conheça as regras de segurança e saiba como se preparar para pedalar no dia a dia da cidade.",
        content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt lacinia, nisl nisl aliquet nisl, nec tincidunt nisl nisl sit amet nisl. Sed euismod, nisl vel tincidunt lacinia, nisl nisl aliquet nisl, nec tincidunt nisl nisl sit amet nisl.",
        imageUrl: "https://images.unsplash.com/photo-1571333250630-f0230c320b6d",
        publishedAt: new Date("2023-05-15"),
        readTime: "5 min de leitura"
      },
      {
        title: "Os melhores roteiros para ciclistas urbanos",
        excerpt: "Descubra os circuitos mais interessantes para explorar a cidade de bike, incluindo parques, mirantes e pontos turísticos acessíveis.",
        content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt lacinia, nisl nisl aliquet nisl, nec tincidunt nisl nisl sit amet nisl. Sed euismod, nisl vel tincidunt lacinia, nisl nisl aliquet nisl, nec tincidunt nisl nisl sit amet nisl.",
        imageUrl: "https://images.unsplash.com/photo-1503376780353-7e6692767b70",
        publishedAt: new Date("2023-05-03"),
        readTime: "8 min de leitura"
      },
      {
        title: "Como a bicicleta ajuda o meio ambiente",
        excerpt: "Entenda o impacto positivo do uso da bicicleta para a redução da emissão de carbono e para a construção de cidades mais sustentáveis.",
        content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt lacinia, nisl nisl aliquet nisl, nec tincidunt nisl nisl sit amet nisl. Sed euismod, nisl vel tincidunt lacinia, nisl nisl aliquet nisl, nec tincidunt nisl nisl sit amet nisl.",
        imageUrl: "https://images.unsplash.com/photo-1592150621744-aca64f48394a",
        publishedAt: new Date("2023-04-28"),
        readTime: "6 min de leitura"
      }
    ];
    
    blogPosts.forEach(post => {
      const id = this.blogPostIdCounter++;
      this.blogPosts.set(id, { ...post, id });
    });
  }
}

export const storage = new MemStorage();
